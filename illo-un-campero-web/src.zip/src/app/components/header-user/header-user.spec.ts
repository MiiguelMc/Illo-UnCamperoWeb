import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderUserComponent  } from './header-user';

describe('HeaderUser', () => {
  let component: HeaderUserComponent ;
  let fixture: ComponentFixture<HeaderUserComponent >;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HeaderUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HeaderUserComponent );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
});
